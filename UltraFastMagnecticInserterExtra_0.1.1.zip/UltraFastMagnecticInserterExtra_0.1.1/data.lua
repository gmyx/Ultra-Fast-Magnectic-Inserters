-- add the 4 inserters
require ("inserters.ultra-fast-inserter")
require ("inserters.ultra-fast-long-inserter")
require ("inserters.ultra-fast-filter-inserter")
require ("inserters.ultra-fast-long-filter-inserter")
require ("inserters.ultra-fast-configurable-inserter")
require ("inserters.ultra-fast-configurable-filter-inserter")

require ("item.ultra-fast-inserter")
require ("recipe.ultra-fast-inserter")
require ("technology.ultra-fast-inserter")


